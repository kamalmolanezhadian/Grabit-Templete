interface Questions {
  questions: string;
  ans: string;
}

const questions: Questions[] = [
  {
    questions: "سوال",
    ans: "جواب",
  },
  {
    questions: "سوال",
    ans: "جواب",
  },
  {
    questions: "سوال",
    ans: "جواب",
  },
  {
    questions: "سوال",
    ans: "جواب",
  },
  {
    questions: "سوال",
    ans: "جواب",
  },
];
export default questions;
