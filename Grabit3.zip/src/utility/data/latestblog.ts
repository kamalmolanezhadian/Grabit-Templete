interface Blog {
    name: string;
    image: string;
    date: string
    title: string;
  }
  
  const latestblog: Blog[] = [
    {
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/1.jpg",
      name: "دسته بندی",
      date: "20 تیر",
      title: "عنوان مقاله",
    },
    {
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/2.jpg",
      date: "April 02,2022",
      name: "دسته بندی",
      title: "عنوان مقاله",
    },
    {
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/3.jpg",
      date: " امروز",
      name: "دسته بندی",
      title: "عنوان مقاله",
    },
    {
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/4.jpg",
      date: "دیروز",
      name: "دسته بندی",
      title: "عنوان مقاله",
    },
    {
        image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/5.jpg",
        date: "فردا",
        name: "دسته بندی",
        title: "عنوان مقاله",
      },
      {
        image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/6.jpg",
        date: "1 سال پیش",
        name: "دسته بندی",
        title: "عنوان مقاله",
      },
  ];
  export default latestblog;