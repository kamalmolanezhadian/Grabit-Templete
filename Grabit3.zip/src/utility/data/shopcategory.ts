interface Shop {
  category: string;
  icon: string;
}

const Shopcategory: Shop[] = [
  {
    category: "Dairy",
    icon: "fi-rr-cupcake",
  },
  {
    category: "Bakery",
    icon: "fi-rr-cupcake",
  },
  {
    category: "دسته بندی",
    icon: "fi fi-rs-apple-whole",
  },
  {
    category: "Dried Fruit",
    icon: "fi fi-rs-apple-whole",
  },
  {
    category: "دسته بندی",
    icon: "fi fi-rs-apple-whole",
  },
  {
    category: "دسته بندی",
    icon: "fi fi-rr-popcorn",
  },
  {
    category: "دسته بندی",
    icon: "fi fi-rr-popcorn",
  },
  {
    category: "دسته بندی",
    icon: "fi fi-rr-popcorn",
  },
  {
    category: "Juice",
    icon: "fi fi-rr-drink-alt",
  },
  {
    category: "Drinks",
    icon: "fi fi-rr-drink-alt",
  },
  {
    category: "تگ",
    icon: "fi fi-rr-drink-alt",
  },
  {
    category: "دسته بندی",
    icon: "fi fi-rr-drink-alt",
  },
  {
    category: "Jewelry",
    icon: "fi fi-rr-drink-alt",
  },
  {
    category: "دسته بندی",
    icon: "fi fi-rr-drink-alt",
  },
];
export default Shopcategory;
