interface Team {
  name: string;
  image: string;
  title: string;
}

const team: Team[] = [
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/user/1.jpg",
    name: "لورم ",
    title: "وضیفه",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/user/2.jpg",
    name: "لورم ",
    title: "وضیفه",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/user/3.jpg",
    name: "لورم",
    title: "وضیفه",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/user/4.jpg",
    name: "لورم",
    title: "وضیفه",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/user/5.jpg",
    name: "لورم",
    title: "وضیفه",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/user/3.jpg",
    name: "لورم",
    title: "وظیفه",
  },
];
export default team;
