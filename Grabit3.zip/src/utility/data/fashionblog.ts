interface Blog {
  name: string;
  image: string;
  date: string;
  title: string;
}

const fashionblog: Blog[] = [
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/9.jpg",
    name: "ساعت",
    date: "دیروز",
    title: "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/10.jpg",
    date: "امروز",
    name: "کفش",
    title: "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/11.jpg",
    date: "فردا",
    name: "فشن",
    title: "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/12.jpg",
    date: "این هفته",
    name: "عینک",
    title: "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/13.jpg",
    date: "یک ساعت پیش",
    name: "کیف",
    title: "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/14.jpg",
    date: "دیروز",
    name: "فشن",
    title: "لورم اپیسوم",
  },
];
export default fashionblog;
