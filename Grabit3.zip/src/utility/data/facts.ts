interface Facts {
    name: string;
    counter: string;
    discription: string;
    item: number;
  }
  
  const facts: Facts[] = [
    {
      counter: "65K+",
      discription: "لورم اپیسوم",
      name: "فروشنده",
      item: 320,
    },
    {
      counter: "$45B+",
      discription: "لورم اپیسوم",
      name: "درامد",
      item: 65,
    },
    {
      counter: "25M+",
      discription: "لورم اپیسوم",
      name: "فروش",
      item: 548,
    },
    {
      counter: "70K+",
      discription: "لورم اپیسوم",
      name: "محصول",
      item: 48,
    },
    
  ];
  export default facts;
  