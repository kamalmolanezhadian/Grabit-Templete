interface Service {
  name: string;
  icon: string;
  title: string;
  num: number;
}

const service: Service[] = [
  {
    icon: "fi-rr-shop",
    name: "پیراهن",
    title: "جزییات",
    num: 36,
  },
  {
    icon: "fi fi-ts-hand-holding-seeding",
    name: "پشتیبانی 24/7",
    title: "جزییات",
    num: 65,
  },
  {
    icon: "fi fi-ts-badge-percent",
    name: "مهلت مرجوعی 30 روزه",
    title: "جزییات",
    num: 65,
  },
  {
    icon: "fi fi-ts-donate",
    name: "امنیت پرداخت",
    title: "جزییات",
    num: 65,
  },
];
export default service;
