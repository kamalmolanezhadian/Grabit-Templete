interface Questions {
    questions: string;
    ans: string;
  }
  
  const questionstwo: Questions[] = [
    {
      questions: "سوال",
      ans: "جواب",
    },
    {
      questions: "سوال",
      ans: "جواب",
    },
    {
      questions: "سوال",
      ans: "جواب",
    },
    {
      questions: "سوال",
      ans: "جواب",
    },
    {
      questions: "سوال",
      ans: "جواب",
    },
  ];
  export default questionstwo;
  