interface Teblist {
    teb : string
  }

  const tab: Teblist[] = [
    {
        teb: ""
    },
    {
        teb: ""
    },
    {
        teb: ""
    },
    {
        teb: ""
    },
  ]