interface Policy {
    questions: string;
  }
  
  const policytwo: Policy[] = [
    {
      questions: "How browsing and vendor works?",
    },
    {
      questions: "Becoming an vendor",
    },
    {
      questions: "How browsing and vendor works?",
    },
    {
      questions: "Becoming an vendor",
    },
    
  ];
  export default policytwo;
  