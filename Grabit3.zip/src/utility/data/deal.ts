interface Deal {
  category: string;
  sale: string;
  image: string;
  imageTwo: string;
  newPrice: number;
  oldPrice: number;
  title: string;
  weight: string;
  rating: any;
  status: string;
  location: string;
  brand: string;
  sku: number;
  quantity: number;
  id: number;
}

const deal: Deal[] = [
  {
    title: "محصول نمونه",
    sale: "Sale",
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/6_1.jpg",
    imageTwo:
      process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/6_2.jpg",
    category: "دسته بندی",
    newPrice: 45.0,
    oldPrice: 56.0,
    location: "Online",
    brand: "Bhisma Organice",
    sku: 23122,
    id: 51,
    quantity: 1,
    weight: "",
    rating: 4,
    status: "Available",
  },
  {
    title: "محصول نمونه",
    sale: "Sale",
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/3_1.jpg",
    imageTwo:
      process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/3_1.jpg",
    category: "دسته بندی",
    weight: "10kg",
    newPrice: 25.0,
    oldPrice: 30.0,
    location: "Online",
    brand: "Bhisma Organice",
    sku: 23122,
    id: 52,
    quantity: 1,
    rating: 3,
    status: "Available",
  },
  {
    title: "محصول نمونه",
    sale: "",
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/9_1.jpg",
    imageTwo:
      process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/9_2.jpg",
    category: "دسته بندی",
    newPrice: 46.0,
    oldPrice: 65.0,
    location: "Online",
    brand: "Bhisma Organice",
    sku: 23122,
    id: 53,
    quantity: 1,
    weight: "",
    rating: 2,
    status: "Available",
  },
  {
    title: "محصول نمونه",
    sale: "Sale",
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/2_1.jpg",
    imageTwo:
      process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/2_2.jpg",
    category: "دسته بندی",
    newPrice: 78.0,
    oldPrice: 85.0,
    location: "Online",
    brand: "Bhisma Organice",
    sku: 23122,
    id: 54,
    quantity: 1,
    weight: "",
    rating: 3,
    status: "Available",
  },
  {
    title: "محصول نمونه",
    sale: "New",
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/1_1.jpg",
    imageTwo:
      process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/1_2.jpg",
    category: "دسته بندی",
    newPrice: 45.0,
    oldPrice: 50.0,
    location: "Online",
    brand: "Bhisma Organice",
    sku: 23122,
    id: 55,
    quantity: 1,
    weight: "2pack",
    rating: 2,
    status: "Out Of Stock",
  },
  {
    title: "محصول نمونه",
    sale: "New",
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/24_1.jpg",
    imageTwo:
      process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/24_1.jpg",
    category: "دسته بندی",
    newPrice: 49.0,
    oldPrice: 65.0,
    location: "Online",
    brand: "Bhisma Organice",
    sku: 23122,
    id: 56,
    quantity: 1,
    weight: "1kg",
    rating: 2,
    status: "Available",
  },
  {
    title: "محصول نمونه",
    sale: "",
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/9_1.jpg",
    imageTwo:
      process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/9_2.jpg",
    category: "دسته بندی",
    newPrice: 20.0,
    oldPrice: 21.0,
    location: "Online",
    brand: "Bhisma Organice",
    sku: 23122,
    id: 53,
    quantity: 1,
    weight: "",
    rating: 2,
    status: "Available",
  },
  {
    title: "محصول نمونه",
    sale: "",
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/17_1.jpg",
    imageTwo:
      process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/17_1.jpg",
    category: "دسته بندی",
    newPrice: 2.0,
    oldPrice: 3.0,
    location: "Online",
    brand: "Bhisma Organice",
    sku: 23122,
    id: 58,
    quantity: 1,
    weight: "100g",
    rating: 4,
    status: "Out Of Stock",
  },
];

export default deal;
