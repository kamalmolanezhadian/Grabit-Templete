interface Material {
  name: string;
}

const material: Material[] = [
  {
    name: "Cotton",
  },
  {
    name: "Georgette",
  },
  {
    name: "Rayon",
  },
  {
    name: "Synthetic",
  },
];
export default material;
