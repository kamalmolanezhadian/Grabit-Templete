interface Weight {
  waight: string;
}

const shopweight: Weight[] = [
  {
    waight: "500گرم",
  },
  {
    waight: "1کیلو",
  },
  {
    waight: "2بسته",
  },
  {
    waight: "2کیلو",
  },
  {
    waight: "5کیلو",
  },
  {
    waight: "10کیلو",
  },
];
export default shopweight;
