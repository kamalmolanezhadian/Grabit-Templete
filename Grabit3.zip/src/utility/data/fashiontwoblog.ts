interface Blog {
  name: string;
  image: string;
  date: string;
  title: string;
  month: string;
}

const fashiontwoblog: Blog[] = [
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/9.jpg",
    name: "ساعت",
    date: "30",
    title: "لورم اپیسوم",
    month: "تیر",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/10.jpg",
    date: "02",
    name: "کفش",
    title: "لورم اپیسوم",
    month: "مهر",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/11.jpg",
    date: "09",
    name: "فشن",
    title: "لورم اپیسوم",
    month: "دی",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/12.jpg",
    date: "25",
    name: "عینک",
    title: "لورم اپیسوم",
    month: "خرداد",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/13.jpg",
    date: "10",
    name: "کیف",
    title: "لورم اپیسوم",
    month: "تیر",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/14.jpg",
    date: "08",
    name: "فشن",
    title: "لورم اپیسوم",
    month: "مرداد",
  },
];
export default fashiontwoblog;
