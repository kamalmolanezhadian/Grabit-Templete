interface Tag {
  name: string;
}

const tags: Tag[] = [
  {
    name: "Clothes",
  },
  {
    name: "Fruits",
  },
  {
    name: "Snacks",
  },
  {
    name: "Dairy",
  },
  {
    name: "Seafood",
  },
  {
    name: "Fastfood",
  },
  {
    name: "Toys",
  },
  {
    name: "perfume",
  },
  {
    name: "jewelry",
  },
  {
    name: "Bags",
  },
];
export default tags;
