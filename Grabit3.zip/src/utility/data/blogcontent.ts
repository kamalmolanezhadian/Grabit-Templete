interface Blog {
  category: string;
  image: string;
  date: string;
  title: string;
  description: string;
}

const blogcontent: Blog[] = [
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/1.jpg",
    category: "دسته بندی",
    date: "امروز",
    title: "لورم اپیسوم",
    description:
      "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/2.jpg",
    date: "دیروز",
    category: "دسته بندی",
    title: "لورم اپیسوم",
    description:
      "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/3.jpg",
    date: "فردا",
    category: "دسته بندی",
    title: "لورم اپیسوم",
    description:
      "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/4.jpg",
    date: "هفته پیش",
    category: "دسته بندی",
    title: "لورم اپیسوم",
    description:
      "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/5.jpg",
    date: "پس فردا",
    category: "دسته بندی",
    title: "لورم اپیسوم",
    description:
      "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/6.jpg",
    date: "یک ماه پیش",
    category: "دسته بندی",
    title: "لورم اپیسوم",
    description:
      "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/1.jpg",
    category: "دسته بندی",
    date: "امروز",
    title: "لورم اپیسوم",
    description:
      "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/2.jpg",
    date: "دیروز",
    category: "دسته بندی",
    title: "لورم اپیسوم",
    description:
      "لورم اپیسوم",
  },
  {
    image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/4.jpg",
    date: "فردا",
    category: "دسته بندی",
    title: "لورم اپیسوم",
    description:
      "لورم اپیسوم",
  },
];
export default blogcontent;
