interface Selling {
    name: string;
    image: string;
    title: string;
    newPrice: number;
    oldPrice: number;
    waight: string
    quantity: number;
    id: number;
  }

  const selling: Selling[] = [
    {
      id: 11212,
      name: "دسته بندی",
      title:"محصول نمونه",
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/18_1.jpg",
      quantity: 1,
      newPrice: 42.00,
      oldPrice: 45.00,
      waight: "5 kg"
    },
    {
      id: 168,
        name: "دسته بندی",
        title:"محصول نمونه",
        image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/28_1.jpg",
        quantity: 1,
        newPrice: 62.00,
        oldPrice: 65.00,
        waight : "1 kg"
      },
      {
        id: 161431,
        name: "دسته بندی",
        title:"محصول نمونه",
        image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/7_2.jpg",
        quantity: 1,
        newPrice: 10.00,
        oldPrice: 11.00,
        waight: "500 g"
      },
      {
        id: 16411,
        name: "دسته بندی",
        title:"Californian Almonds Value Pack",
        image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/3_1.jpg",
        quantity: 1,
        newPrice: 25.00,
        oldPrice: 30.00,
        waight: "250 g"
      },
      {
        id: 121293,
        name: "دسته بندی",
        title:"محصول نمونه",
        image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/13_1.jpg",
        quantity: 1,
        newPrice: 20.00,
        oldPrice: 30.00,
        waight: "12 واحد"
      },
      {
        id: 16141,
        name: "دسته بندی",
        title:"Berry & Graps Mix Snack",
        image: process.env.NEXT_PUBLIC_URL + "/assets/img/product-images/5_1.jpg",
        quantity: 1,
        newPrice: 52.00,
        oldPrice: 55.00,
        waight: "1 واحد"
      },
  ]
  export default selling;