interface Service {
  name: string;
  icon: string;
  title: string;
}

const service: Service[] = [
  {
    icon: "fi fi-ts-truck-moving",
    name: "ارسال رایگان",
    title: "جزییات",
  },
  {
    icon: "fi fi-ts-hand-holding-seeding",
    name: "پشتیبانی 24/7",
    title: "جزییات",
  },
  {
    icon: "fi fi-ts-badge-percent",
    name: "مهلت مرجوعی 30روزه",
    title: "جزییات",
  },
  {
    icon: "fi fi-ts-donate",
    name: "امنیت پرداخت",
    title: "جزییات",
  },
];
export default service