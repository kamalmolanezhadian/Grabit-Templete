interface Term {
    questions: string;
  }
  
  const term: Term[] = [
    {
      questions: "Becoming an vendor",
    },
    {
      questions: "How browsing and vendor works?",
    },
    {
      questions: "Becoming an vendor",
    },
    {
      questions: "How browsing and vendor works?",
    },
    
  ];
  export default term;
  