interface Term {
    questions: string;
  }
  
  const termtwo: Term[] = [
    {
      questions: " How browsing and vendor works?",
    },
    {
      questions: "Becoming an vendor",
    },
    {
      questions: " How browsing and vendor works?",
    },
    {
      questions: "Becoming an vendor",
    },
   
  ];
  export default termtwo;
  