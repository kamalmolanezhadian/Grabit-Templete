interface Blog {
    category: string;
    image: string;
    date: string;
    title: string;
    description: string
  }
  
  const recentblog: Blog[] = [
    {
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/6.jpg",
      category: "- طبیعی",
      date: "یک سال پیش",
      title: "پست نمونه",
      description: "لورم اپیسوم"
    },
    {
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/5.jpg",
      date: "یک ماه پیش",
      category: "- میوجات",
      title: "پست نمونه",
      description: "لورم اپیسوم"
    },
    {
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/4.jpg",
      date: "یک هفته پیش",
      category: "- سبزیجات",
      title: "پست نمونه",
      description: "لورم اپیسوم"
    },
    {
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/3.jpg",
      date: "دیروز",
      category: "- Fastfood",
      title: "پست نمونه",
      description: "لورم اپیسوم"
    },
    {
      image: process.env.NEXT_PUBLIC_URL + "/assets/img/blog/2.jpg",
      date: "امروز",
      category: "- سبزیجات",
      title: "پست نمونه",
      description: "لورم اپیسوم"
    },
    
  ];
  export default recentblog;
  