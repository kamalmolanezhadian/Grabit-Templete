"use client";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../store";
import StarRating from "../stars/StarRating";
import { addItem } from "../../store/reducers/cartSlice";
import { addWishlist } from "@/store/reducers/wishlistSlice";
import { removeCompareItem } from "@/store/reducers/compareSlice";

interface Item {
  id: number;
  title: string;
  newPrice: number;
  waight: string;
  image: string;
  imageTwo: string;
  date: string;
  status: string;
  rating: number;
  oldPrice: number;
  location: string;
  brand: string;
  sku: number;
  category: string;
  quantity: number;
}

const Compare = () => {
  const CompareItem = useSelector((state: RootState) => state.compare.compare);
  const dispatch = useDispatch();

  const handleCart = (data: Item) => {
    dispatch(addItem(data));
  };

  const handleRemoveCompareItem = (data: any) => {
    dispatch(removeCompareItem(data.id));
  };

  const handleWishlist = (data: Item) => {
    dispatch(addWishlist(data));
  };

  if (CompareItem.length === 0) {
    return (
      <div style={{ textAlign: "center" }} className="gi-compare-col">
        <h5>اینجا چیزی نیست</h5>
      </div>
    );
  }

  return (
    <>
      <section className="gi-compare padding-tb-40">
        <h2 className="d-none"> مقایسه </h2>
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="gi-compare-box">
                <div className="gi-compare-col title-col">
                  <div className="gi-compare-cell">
                    <div className="title">
                      <h5>تصویر محصولات</h5>
                    </div>
                  </div>
                  <div className="gi-compare-cell">
                    <h5>اسم</h5>
                  </div>
                  <div className="gi-compare-cell">
                    <h5>دسته بندی</h5>
                  </div>
                  <div className="gi-compare-cell">
                    <h5>امتیاز</h5>
                  </div>
                  <div className="gi-compare-cell">
                    <h5>وضعیت</h5>
                  </div>
                  <div className="gi-compare-cell">
                    <h5>موقعیت</h5>
                  </div>
                  <div className="gi-compare-cell">
                    <h5>برند</h5>
                  </div>
                  <div className="gi-compare-cell">
                    <h5>ایدی</h5>
                  </div>
                  <div className="gi-compare-cell">
                    <h5>تعداد</h5>
                  </div>
                  <div className="gi-compare-cell">
                    <h5>وزن</h5>
                  </div>
                  <div className="gi-compare-cell">
                    <div className="desc">
                      <h5>جزییات</h5>
                    </div>
                  </div>
                </div>
                {CompareItem.map((data, index) => (
                  <div key={index} className="gi-compare-col">
                    <a
                      onClick={() => handleRemoveCompareItem(data)}
                      className="remove-compare-product"
                    >
                      <img
                        src={
                          process.env.NEXT_PUBLIC_URL +
                          "/assets/img/icons/close.svg"
                        }
                        className="svg_img"
                        alt="close"
                      />
                    </a>
                    <div className="gi-compare-cell">
                      <div className="list">
                        <img src={data.image} alt="product" />
                        <div className="gi-action">
                          <ul>
                            <li>
                              <a
                                className="gi-btn-group wishlist"
                                onClick={() => handleWishlist(data)}
                                title="Wishlist"
                              >
                                <i className="fi-rr-heart"></i>
                              </a>
                            </li>
                            <li>
                              <a
                                title="Add To Cart"
                                onClick={() => handleCart(data)}
                                className="gi-btn-group add-to-cart"
                              >
                                <i className="fi-rr-shopping-basket"></i>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div className="gi-compare-cell">
                      <p>محصول نمونه</p>
                    </div>
                    <div className="gi-compare-cell">
                      <p>دسته بندی</p>
                    </div>
                    <div className="gi-compare-cell">
                      <span className="gi-pro-rating">
                        <StarRating rating={data.rating} />
                      </span>
                      <p className="rating-info">(-3 نظر)</p>
                    </div>
                    <div className="gi-compare-cell">
                      <p
                        className="i-stock"
                      >
                        موجود
                      </p>
                    </div>
                    <div className="gi-compare-cell">
                      <p>آنلاین</p>
                    </div>
                    <div className="gi-compare-cell">
                      <p>برند</p>
                    </div>
                    <div className="gi-compare-cell">
                      <p>{data.sku}</p>
                    </div>
                    <div className="gi-compare-cell">
                      <p>1 بسته</p>
                    </div>
                    <div className="gi-compare-cell">
                      <p>1 کیلو</p>
                    </div>
                    <div className="gi-compare-cell">
                      <div className="desc">
                        <p>
                          لورم اپیسوم
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Compare;
