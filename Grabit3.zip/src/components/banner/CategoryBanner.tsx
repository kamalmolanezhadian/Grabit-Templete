import Link from "next/link";
import React from "react";

const CategoryBanner = () => {
  return (
    <>
      <div className="padding-b-40 m-b-40">
        <div className="row">
          <div className="col-md-6">
            <div className="gi-ofr-banners">
              <div className="gi-bnr-body">
                <div className="gi-bnr-img">
                  <span className="lbl">70% تخفیف</span>
                  <img
                    src={
                      process.env.NEXT_PUBLIC_URL + "/assets/img/banner/5.jpg"
                    }
                    alt="banner"
                  />
                </div>
                <div className="gi-bnr-detail">
                  <h5>میوه و سبزیجات</h5>
                  <p>لورم اپیسوم</p>
                  <Link href="/shop-left-sidebar-col-3" className="gi-btn-2">
                    الان بخر
                  </Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <div className="gi-ofr-banners m-t-767">
              <div className="gi-bnr-body">
                <div className="gi-bnr-img">
                  <span className="lbl">50% تخفیف</span>
                  <img
                    src={
                      process.env.NEXT_PUBLIC_URL + "/assets/img/banner/6.jpg"
                    }
                    alt="banner"
                  />
                </div>
                <div className="gi-bnr-detail">
                  <h5>فست فود</h5>
                  <p>لورم اپیسوم</p>
                  <Link href="/shop-left-sidebar-col-3" className="gi-btn-2">
                    الان بخر
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CategoryBanner;
