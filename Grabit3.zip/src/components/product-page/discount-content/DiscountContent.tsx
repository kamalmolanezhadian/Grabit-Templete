import { getRegistrationData } from "@/components/login/RegisterPage";
import RatingComponent from "@/components/stars/RatingCompoents";
import { RootState } from "@/store";
import React, { useEffect, useState } from "react";
import { Form } from "react-bootstrap";
import { useSelector } from "react-redux";

const DiscountContent = () => {
  const login = useSelector(
    (state: RootState) => state.registration.isAuthenticated
  );
  const [userData, setUserData] = useState<any | null>(null);
  const [validated, setValidated] = useState(false);
  const [activeAccordion, setActiveAccordion] = useState(null);
  const [comment, setComment] = useState("");
  const [rating, setRating] = useState(0);
  const [reviews, setReviews] = useState([
    {
      name: "موریس",
      rating: 3,
      comment:
        "لورم اپیسوم",
      avatar: "/assets/img/avatar/placeholder.jpg",
    },
  ]);

  useEffect(() => {
    if (login) {
      const data = getRegistrationData();
      if (data?.length > 0) {
        setUserData(data[data.length - 1]);
      }
    }
  }, [login]);

  const handleAccordionToggle = (index) => {
    setActiveAccordion(index === activeAccordion ? null : index);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;

    if (form.checkValidity() === false) {
      e.stopPropagation();
    } else {
      if (userData && comment && rating) {
        setReviews([
          ...reviews,
          {
            name: `${userData.firstName} ${userData.lastName}`,
            rating,
            comment,
            avatar: userData.profilePhoto || "/assets/img/avatar/placeholder.jpg",
          },
        ]);

        setComment("");
        setRating(0);
      }
    }

    setValidated(true);
  };
  return (
    <>
      <div className={`gi-accordion style-1 gi-single-pro-tab-content`}>
        <div
          className={`gi-accordion-item ${
            activeAccordion === 0 ? "active" : ""
          }`}
        >
          <h4
            className="gi-accordion-header"
            onClick={() => handleAccordionToggle(0)}
          >
            جزییات محصول
          </h4>
          <div
            className={`gi-accordion-body ${
              activeAccordion === 0 ? "show" : ""
            }`}
          >
            <div className="gi-single-pro-tab-desc">
              <p>
                لورم اپیسوم
              </p>
              <ul>
                <li> لورم اپیسوم </li>
                <li>لورم اپیسوم </li>
                <li>لورم اپیسوم </li>
                <li>لورم اپیسوم </li>
              </ul>
              <p>
              لورم اپیسوم 
              </p>
              <p>
              لورم اپیسوم 
              </p>
            </div>
          </div>
        </div>
        <div
          className={`gi-accordion-item ${
            activeAccordion === 1 ? "active" : ""
          }`}
        >
          <h4
            className="gi-accordion-header"
            onClick={() => handleAccordionToggle(1)}
          >
            لورم اپیسوم 
          </h4>
          <div
            className={`gi-accordion-body ${
              activeAccordion === 1 ? "show" : ""
            }`}
          >
            <div className="gi-single-pro-tab-moreinfo">
              <p>
              لورم اپیسوم 
              </p>
              <ul>
                <li>
                  <span>مدل</span> SKU140
                </li>
                <li>
                  <span>وزن</span> 500 g
                </li>
                <li>
                  <span>ابعاد</span> 35 × 30 × 7 cm
                </li>
                <li>
                  <span>رنگ</span> Black, Pink, Red, White
                </li>
                <li>
                  <span>اندازه</span> 10 X 20
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div
          className={`gi-accordion-item ${
            activeAccordion === 2 ? "active" : ""
          }`}
        >
          <h4
            className="gi-accordion-header"
            onClick={() => handleAccordionToggle(2)}
          >
            فروشنده.
          </h4>
          <div
            className={`gi-accordion-body ${
              activeAccordion === 2 ? "show" : ""
            }`}
          >
            <div className="gi-single-pro-tab-moreinfo">
              <div className="gi-product-vendor">
                <div className="gi-vendor-info">
                  <span>
                    <img
                      src={
                        process.env.NEXT_PUBLIC_URL + "/assets/img/vendor/3.jpg"
                      }
                      alt="vendor"
                    />
                  </span>
                  <div>
                    <h5>لورم اپیسوم </h5>
                    <p>محصولات : 358</p>
                    <p>فروش : 5587</p>
                  </div>
                </div>
                <div className="gi-detail">
                  <ul>
                    <li>
                      <span>تماس :</span> 09123456789
                    </li>
                    <li>
                      <span>ایمیل :</span> Example@gmail.com
                    </li>
                    <li>
                      <span>آدرس :</span> لورم اپیسوم 
                    </li>
                  </ul>
                  <p>
                  لورم اپیسوم 
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          className={`gi-accordion-item ${
            activeAccordion === 3 ? "active" : ""
          }`}
        >
          <h4
            className="gi-accordion-header"
            onClick={() => handleAccordionToggle(3)}
          >
            نظرات
          </h4>
          <div
            className={`gi-accordion-body p-b-0 ${
              activeAccordion === 3 ? "show" : ""
            }`}
          >
            <div id="gi-spt-nav-review" className="a-tab-pane">
            {!login ? (
                <div className="container">
                  <p>
                    برای ثبت نظر  <a href="/login"> وارد شوید  </a> یا {" "}
                    <a href="/register">ثبت نام</a> کنید
                  </p>
                </div>
              ) : (
                <div className="row">
                  <div className="gi-t-review-wrapper">
                    {reviews.map((data, index) => (
                      <div key={index} className="gi-t-review-item">
                        <div className="gi-t-review-avtar">
                          <img
                            src={
                              data.avatar ||
                              process.env.NEXT_PUBLIC_URL +
                                "/assets/img/avatar/placeholder.jpg"
                            }
                            alt="user"
                          />
                        </div>
                        <div className="gi-t-review-content">
                          <div className="gi-t-review-top">
                            <div className="gi-t-review-name">{data.name}</div>
                            <div className="gi-t-review-rating">
                              {[...Array(5)].map((_, i) => (
                                <i
                                  key={i}
                                  className={`gicon gi-star ${
                                    i < data.rating ? "fill" : "gi-star-o"
                                  }`}
                                ></i>
                              ))}
                            </div>
                          </div>
                          <div className="gi-t-review-bottom">
                            <p>{data.comment}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="gi-ratting-content">
                    <h3>ثبت نظر</h3>
                    <div className="gi-ratting-form">
                      <Form
                        noValidate
                        validated={validated}
                        onSubmit={handleSubmit}
                        action="#"
                      >
                        <div className="gi-ratting-star">
                          <RatingComponent
                            onChange={setRating}
                            value={rating}
                          />
                        </div>
                        <div className="gi-ratting-input form-submit">
                          <Form.Group>
                            <Form.Control
                              as="textarea"
                              name="comment"
                              placeholder="پاسخ شما"
                              value={comment}
                              onChange={(e) => setComment(e.target.value)}
                              required
                            />
                            <Form.Control.Feedback
                              type="invalid"
                            >
                              پاسخ بدین
                            </Form.Control.Feedback>
                          </Form.Group>
                          <button style={{marginTop : "15px"}} className="gi-btn-2" type="submit">
                            ارسال
                          </button>
                        </div>
                      </Form>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default DiscountContent;
