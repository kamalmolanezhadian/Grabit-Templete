import Shop from "../shop-sidebar/Shop";
import { Col, Row } from "react-bootstrap";

const SingleCatelog = () => {
  return (
    <>
      <section className="gi-single-vendor padding-tb-40">
        <div className="container">
          <Row>
            <Col lg={12}>
              <div className="gi-page-description">
                <img
                  src={process.env.NEXT_PUBLIC_URL + "/assets/img/vendor/1.jpg"}
                  alt="vendor"
                />
                <div className="detail">
                  <h5 className="gi-desc-title">لورم</h5>
                  <p>
                    لورم اپیسوم
                  </p>
                </div>
              </div>
            </Col>
          </Row>
          <Row>
            <Col lg={3} md={6}>
              <div className="gi-vendor-dashboard-sort-card">
                <h5>اسم</h5>
                <span>( لورم )</span>
              </div>
            </Col>
            <Col lg={3} md={6}>
              <div className="gi-vendor-dashboard-sort-card">
                <h5>سطح</h5>
                <span>سطح 9 از 10</span>
              </div>
            </Col>
            <Col lg={3} md={6}>
              <div className="gi-vendor-dashboard-sort-card">
                <h5>محصولات فروشنده</h5>
                <span>568 محصول</span>
              </div>
            </Col>
            <Col lg={3} md={6}>
              <div className="gi-vendor-dashboard-sort-card">
                <h5>عمر فروشنده</h5>
                <span>زیر 1 ثانیه</span>
              </div>
            </Col>
          </Row>
        </div>
      </section>
      <section className="gi-shop">
        <div className="container">
          <Shop order={"order-lg-last order-md-first"} lg={9} xl={4} />
        </div>
      </section>
    </>
  );
};

export default SingleCatelog;
