"use client";
import { useSelector } from "react-redux";
import { RootState } from "@/store";
import VendorSidebar from "../vendor-sidebar/VendorSidebar";

import { PDFContent } from "@/components/pdf-content/PDFContent";

const UserInvoice = () => {
  const login = useSelector(
    (state: RootState) => state.registration.isAuthenticated
  );

  if (!login) {
    return (
      <div className="container">
        <p>
          برای دیدن محتوا لطفا <a href="/login"> واردشوید </a> یا <a href="/register"> ثبت نام کنید </a>{" "}
          
        </p>
      </div>
    );
  }
  return (
    <>
      <section className="gi-User-invoice padding-tb-40">
        <div className="container">
          <div className="row mb-minus-24px">
            <VendorSidebar />
            <div className="col-lg-9 col-md-12 mb-24">
              <div className="gi-vendor-dashboard-card">
                <PDFContent
                  title="Invoice"
                  pageSize="A4"
                  margins="20mm"
                  fileName="user-invoice.pdf"
                >
                  <div className="gi-Track-image-inner">
                    <img
                      src={
                        process.env.NEXT_PUBLIC_URL +
                        "/assets/img/logo/logo.png"
                      }
                      alt="Site Logo"
                    />
                  </div>
                  <div className="row invoice-p-30">
                    <div className="col-sm-6">
                      <div className="my-2">
                        <span className="text-sm text-grey-m2 align-middle">
                          To :{" "}
                        </span>
                        <span className="name">جان</span>
                      </div>
                      <div className="text-grey-m2">
                        <div className="my-2">آدرس</div>
                        <div className="my-2">کشور</div>
                        <div className="my-2">
                          <b className="text-600">تماس : </b>09123456789
                        </div>
                      </div>
                    </div>
                    <div className="text-95 col-sm-6 align-self-start d-sm-flex justify-content-end">
                      <hr className="d-sm-none" />
                      <div className="text-grey-m2">
                        <div className="my-2">
                          <span className="text-600 text-90">ایدی : </span>
                          #111-222
                        </div>

                        <div className="my-2">
                          <span className="text-600 text-90">کد :</span>{" "}
                          #123456
                        </div>
                        <div className="my-2">
                          <span className="text-600 text-90">تاریخ شروع :</span>{" "}
                          امروز
                        </div>

                        <div className="my-2">
                          <span className="text-600 text-90">تعداد فروشنده :</span>
                          6548
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="gi-vendor-card-body">
                    <div className="gi-vendor-card-table mb-minus-24px">
                      <table className="table gi-vender-table">
                        <thead>
                          <tr>
                            <th scope="col">ایدی</th>
                            <th scope="col">اسم</th>
                            <th scope="col">تعداد</th>
                            <th scope="col">قیمت</th>
                            <th scope="col">جمع کل</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row">
                              <span>225</span>
                            </th>
                            <td>
                              <span>لورم اپیسوم</span>
                            </td>
                            <td>
                              <span>2</span>
                            </td>
                            <td>
                              <span>30 تومان</span>
                            </td>
                            <td>
                              <span>320 تومان</span>
                            </td>
                          </tr>
                          <tr>
                            <th scope="row">
                              <span>548</span>
                            </th>
                            <td>
                              <span>لورم اپیسوم</span>
                            </td>
                            <td>
                              <span>5</span>
                            </td>
                            <td>
                              <span>40 تومان</span>
                            </td>
                            <td>
                              <span>214 تومان</span>
                            </td>
                          </tr>
                          <tr>
                            <th scope="row">
                              <span>684</span>
                            </th>
                            <td>
                              <span>لورم اپیسوم</span>
                            </td>
                            <td>
                              <span>3</span>
                            </td>
                            <td>
                              <span>10 تومان</span>
                            </td>
                            <td>
                              <span>548 تومان</span>
                            </td>
                          </tr>
                          <tr>
                            <th scope="row">
                              <span>987</span>
                            </th>
                            <td>
                              <span>لورم اپیسوم</span>
                            </td>
                            <td>
                              <span>1</span>
                            </td>
                            <td>
                              <span>50  تومان</span>
                            </td>
                            <td>
                              <span>200 تومان</span>
                            </td>
                          </tr>
                        </tbody>
                        <tfoot>
                          <tr>
                            <td className="border-none" colSpan={3}>
                              <span></span>
                            </td>
                            <td className="border-color" colSpan={1}>
                              <span>
                                <strong>جمع کل</strong>
                              </span>
                            </td>
                            <td className="border-color">
                              <span>3520 تومان</span>
                            </td>
                          </tr>
                          <tr>
                            <td className="border-none" colSpan={3}>
                              <span></span>
                            </td>
                            <td className="border-color" colSpan={1}>
                              <span>
                                <strong>کارمزد (10%)</strong>
                              </span>
                            </td>
                            <td className="border-color">
                              <span>352 تومان</span>
                            </td>
                          </tr>
                          <tr>
                            <td className="border-none m-m15" colSpan={3}>
                              <span className="note-text-color">
                                لورم اپیسوم
                              </span>
                            </td>
                            <td className="border-color m-m15" colSpan={1}>
                              <span>
                                <strong>جمع</strong>
                              </span>
                            </td>
                            <td className="border-color m-m15">
                              <span>3872 تومان</span>
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                </PDFContent>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default UserInvoice;
