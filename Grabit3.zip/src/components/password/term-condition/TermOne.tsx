import useSWR from "swr";
import fetcher from "../../fetcher-api/Fetcher";
import Spinner from "@/components/button/Spinner";

const TermOne = ({
  onSuccess = () => {},
  hasPaginate = false,
  onError = () => {},
}) => {
  const { data, error } = useSWR("/api/termone", fetcher, {
    onSuccess,
    onError,
  });

  if (error) return <div> مشکل در لود کردن محصولات </div>;
  if (!data)
    return (
      <div>
        <Spinner />
      </div>
    );

  const getData = () => {
    if (hasPaginate) return data.data;
    else return data;
  };

  return (
    <>
      <div className="gi-common-wrapper">
        {getData().map((item: any, index: any) => (
          <div key={index} className="col-sm-12 gi-cgi-block">
            <div className="gi-cgi-block-inner">
              <h5 className="gi-cgi-block-title">{item.questions}</h5>
              <p>
                لورم اپیسوم
              </p>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default TermOne;
