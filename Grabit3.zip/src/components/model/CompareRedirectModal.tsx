// components/CompareRedirectModal.tsx
import { Modal, Button } from "react-bootstrap";

interface CompareRedirectModalProps {
  show: boolean;
  handleClose: () => void;
  handleRedirect: () => void;
}

const CompareRedirectModal = ({
  show,
  handleClose,
  handleRedirect,
}: CompareRedirectModalProps) => {
  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>مقایسه محصولات</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        لورم اپیسوم
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          لغو
        </Button>
        <Button variant="primary" onClick={handleRedirect}>
          نمایش صفحه
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default CompareRedirectModal;
