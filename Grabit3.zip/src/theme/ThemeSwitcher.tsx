"use client";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "@/store";
import { setTheme, toggleMode, setDirection } from "@/store/reducers/themeSlice";
import { useEffect, useState } from "react";
import {colorCss} from "../utility/data/colorCss";
import Link from "next/link";

const ThemeSwitcher = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { theme, mode, direction } = useSelector((state: RootState) => state.theme);
  const [isOpen, setIsOpen] = useState(false);

  
  useEffect(() => {
    // Remove previous color stylesheets
    document.querySelectorAll("link[data-theme]").forEach((el) => el.remove());

    // Apply new theme color stylesheet
    const themeLink = document.createElement("link");
    themeLink.rel = "stylesheet";
    themeLink.href = `/assets/css/${theme}.css`;
    themeLink.setAttribute("data-theme", "true");
    document.head.appendChild(themeLink);

    // Handle dark mode dynamically
    const darkLinkId = "dark-mode";
    if (mode === "dark") {
      if (!document.getElementById(darkLinkId)) {
        const darkLink = document.createElement("link");
        darkLink.id = darkLinkId;
        darkLink.rel = "stylesheet";
        darkLink.href = "/assets/css/dark.css";

        // Set background only after dark.css is loaded
        darkLink.onload = () => {
          document.body.style.backgroundColor = "#161a2a";
        };

        document.head.appendChild(darkLink);
      } else {
        document.body.style.backgroundColor = "#161a2a"; // If dark.css already exists
      }
    } else {
      document.getElementById(darkLinkId)?.remove();
      document.body.style.backgroundColor = "#fff";
    }

    // Handle RTL stylesheet
    const rtlLinkId = "rtl-link";
    if (direction === "RTL") {
      if (!document.getElementById(rtlLinkId)) {
        const rtlLink = document.createElement("link");
        rtlLink.id = rtlLinkId;
        rtlLink.rel = "stylesheet";
        rtlLink.href = "/assets/css/rtl.css";
        document.head.appendChild(rtlLink);
      }
    } else {
      document.getElementById(rtlLinkId)?.remove();
    }

    // Apply mode and direction classes
    document.body.className = `${theme} ${mode} ${direction}`;

    return () => {
      themeLink.remove();
      document.getElementById(rtlLinkId)?.remove();
    };
  }, [theme, mode, direction]);

  const toggleSidebar = (e: any) => {
    e.preventDefault();
    setIsOpen(!isOpen);
  };

  const closeSidebar = () => {
    setIsOpen(false);
  };

  const handleDirection = (mode: "LTR" | "RTL") => {
    dispatch(setDirection(mode));
    setTimeout(() => {
      window.location.reload();
    }, 100);
  }


  return (
    <>
      
    </>
  );
};

export default ThemeSwitcher;
