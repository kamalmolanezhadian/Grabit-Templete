import EmailForgetPasswordThree from "@/components/email/email-forgot/EmailForgetPasswordThree"
const page = () => {
  return (
    <>
      <EmailForgetPasswordThree />
    </>
  )
}

export default page