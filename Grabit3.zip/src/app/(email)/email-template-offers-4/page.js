import EmailOfferFour from "@/components/email/email-offer/EmailOfferFour"

const page = () => {
  return (
    <>
      <EmailOfferFour />
    </>
  )
}

export default page