import EmailOfferTwo from "@/components/email/email-offer/EmailOfferTwo"

const page = () => {
  return (
    <>
      <EmailOfferTwo />
    </>
  )
}

export default page