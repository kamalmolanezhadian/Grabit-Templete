import EmailOfferThree from "@/components/email/email-offer/EmailOfferThree"

const page = () => {
  return (
    <>
      <EmailOfferThree />
    </>
  )
}

export default page