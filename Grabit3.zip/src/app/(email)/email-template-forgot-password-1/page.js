import EmailForgetPassword from "@/components/email/email-forgot/EmailForgetPassword"

const page = () => {
  return (
    <>
      <EmailForgetPassword />
    </>
  )
}

export default page