import EmailTemplateTwo from "@/components/email/email-conform/EmailTemplateTwo"

const page = () => {
  return (
    <>
      <EmailTemplateTwo />
    </>
  )
}

export default page