import Breadcrumb from '@/components/breadcrumb/Breadcrumb'
import WishlistThree from '@/components/wishlist/WishlistThree'



const page = () => {
    return (
        <>


            <Breadcrumb title={"لیست علاقمندی"} />
            <WishlistThree />

        </>
    )
}

export default page
