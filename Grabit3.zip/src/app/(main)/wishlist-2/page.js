import Breadcrumb from '@/components/breadcrumb/Breadcrumb'
import WishlistTwo from '@/components/wishlist/WishlistTwo'



const page = () => {
    return (
        <>


            <Breadcrumb title={"لیست علاقمندی"} />
            <WishlistTwo />

        </>
    )
}

export default page
