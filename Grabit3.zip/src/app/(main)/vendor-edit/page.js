import VandorEdit from '@/components/profile-Edit/VandorEdit'

const page = () => {
    return (
        <>


            <VandorEdit />

        </>
    )
}

export default page
