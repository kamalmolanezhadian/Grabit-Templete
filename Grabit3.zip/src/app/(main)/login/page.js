import LoginPage from '@/components/login/LoginPage'

const page = () => {
    return (
        <>


            <LoginPage />

        </>
    )
}

export default page
