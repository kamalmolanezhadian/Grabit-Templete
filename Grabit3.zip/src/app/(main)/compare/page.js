"use client";;
import Breadcrumb from '@/components/breadcrumb/Breadcrumb';
import Compare from '@/components/compare/Compare';



const page = () => {
    return (
        <>


            <Breadcrumb title={"مقایسه"} />
            <Compare />

        </>
    )
}

export default page
