import CheckOut from '@/components/login/CheckOut'

const page = () => {
    return (
        <>


            <CheckOut />

        </>
    )
}

export default page
